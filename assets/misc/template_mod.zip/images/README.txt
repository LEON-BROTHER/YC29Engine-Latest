== DROP YOUR IMAGES AND ATLASES HERE ==

You can access them using Paths.getSparrowAtlas and Paths.image

For example, Paths.image("test") will return the image located at "images/test.png"