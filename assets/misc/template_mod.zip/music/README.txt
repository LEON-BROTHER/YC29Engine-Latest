== DROP YOUR .OGG FILES HERE ==

They can be accessed via Paths.music.

You can also for example override the main menu music by adding a file named "freakyMenu.ogg".